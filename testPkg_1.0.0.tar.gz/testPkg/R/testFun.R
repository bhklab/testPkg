#' @title Squares a number
#'
#' @description
#' This function accepts and numeric vector and returns it's value squared.
#'
#' @param x `numeric(1)` A numeric vector of numbers to square.
#'
#' @return `n`
#'
#' @export
myFun <- function(x) {
    stopifnot(length(x) == 1 || is.character(x))
    x ** 2
}